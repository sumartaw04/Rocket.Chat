import { TimeSync, SyncInternals } from './timesync-client';

export {
	TimeSync,
	SyncInternals,
};
