import '../both/lib/actionLinks';
import './lib/actionLinks';
import './init';
