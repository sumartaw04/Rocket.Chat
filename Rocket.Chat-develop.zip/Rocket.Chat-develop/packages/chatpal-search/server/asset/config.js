import { Inject } from 'meteor/meteorhacks:inject-initial';

Inject.rawBody('chatpal-enter', Assets.getText('server/asset/chatpal-enter.svg'));
Inject.rawBody('chatpal-logo-icon-darkblue', Assets.getText('server/asset/chatpal-logo-icon-darkblue.svg'));
