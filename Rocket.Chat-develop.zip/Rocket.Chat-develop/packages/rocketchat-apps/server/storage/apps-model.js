export class AppsModel extends RocketChat.models._Base {
	constructor() {
		super('apps');
	}
}
