import './inputs.html';
import './templates';
import AutoComplete from './autocomplete-client';

export {
	AutoComplete,
};
