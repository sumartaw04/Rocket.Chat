import { Mongo } from 'meteor/mongo';

export default new Mongo.Collection('autocompleteRecords');
