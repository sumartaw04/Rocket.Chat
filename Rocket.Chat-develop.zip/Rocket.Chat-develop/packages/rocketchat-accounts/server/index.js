import './config';

import AccountsServer from '@accounts/server';


export {
	AccountsServer,
};
