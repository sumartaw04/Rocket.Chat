# rocketchat:accounts

Integration with `js-accounts` system.
