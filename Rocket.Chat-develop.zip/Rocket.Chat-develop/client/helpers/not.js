import { Template } from 'meteor/templating';

Template.registerHelper('not', (value) => !value);
