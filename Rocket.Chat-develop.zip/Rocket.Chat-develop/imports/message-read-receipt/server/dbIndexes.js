RocketChat.models.Messages.tryEnsureIndex({
	unread: 1,
}, {
	sparse: true,
});
