# Reporting Security Issues

Please report any security issues you discovered to security[at]rocket[dot]chat

We will assess the risk, plus make a fix available before we create a GitHub issue.

Thank you for your contribution.
